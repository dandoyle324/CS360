package com.cs360.doyleprojectoption1inventoryapp;

public interface RVInterface {
    void onItemClick(int pos, String item, String qty);
    void deleteItem(String item);
}
