package com.cs360.doyleprojectoption1inventoryapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;

import java.util.ArrayList;

public class Inventory extends AppCompatActivity implements RVInterface{

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private EditText addItemName, addItemQuantity, editItemQty;
    private TextView editItemName;
    private Button addItemBtn, cancelAddBtn, submitEditBtn, cancelEditBtn;
    private ImageView settingsButton;
    private InventoryDB DB;
    private RecyclerView recyclerView;
    private ArrayList<String> names, qtys;
    private RVAdapter rvAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_database);

        DB = new InventoryDB(this);
        names = new ArrayList<>();
        qtys = new ArrayList<>();
        recyclerView = findViewById(R.id.rv_items);
        displayItems();
        rvAdapter = new RVAdapter(this, names, qtys, this);
        recyclerView.setAdapter(rvAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Opens Settings Activity
        settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(view -> {
            Intent intent=new Intent(Inventory.this, SMSAlertScreen.class);
            startActivity(intent);
        });

    }

    private void displayItems() { // Displays all items in DB in RV
        Cursor cursor = DB.getItemsInDB();
        if(cursor.getCount()==0) {
            Toast.makeText(Inventory.this, "No items in inventory database!", Toast.LENGTH_LONG).show();
            return;
        } else {
            while(cursor.moveToNext()) {
                names.add(cursor.getString(0));
                qtys.add(cursor.getString(1));
            }
        }
    }

    public void addItem(View view) {
        createNewAddItemDialog();
    } // Calls the Add Item Dialog

    public void createNewAddItemDialog(){ // Dialog for adding items to DB and RV
        dialogBuilder = new AlertDialog.Builder(this);
        final View addItemPopupView = getLayoutInflater().inflate(R.layout.popup_additem, null);
        addItemName = (EditText)  addItemPopupView.findViewById(R.id.additempopup_itemname);
        addItemQuantity = (EditText)  addItemPopupView.findViewById(R.id.additempopup_itemquantity);
        addItemBtn = (Button) addItemPopupView.findViewById(R.id.additempopup_add);
        cancelAddBtn = (Button) addItemPopupView.findViewById(R.id.additempopup_cancel);

        dialogBuilder.setView(addItemPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        // Add button submits the entered data into the DB and RV
        addItemBtn.setOnClickListener(v -> {
            String itemName = addItemName.getText().toString();
            String itemQuantity = addItemQuantity.getText().toString();
            if (itemName.equals("") || itemQuantity.equals("")) {
                //addError.setText("Please ensure both fields are filled out!");
            } else {
                Boolean itemExists = DB.checkItemExists(itemName);
                if (itemExists){
                //addError.setText("Item already exists!");
                } else {
                    DB.addItem(itemName, Integer.parseInt(itemQuantity)); // Add to DB
                    rvAdapter.addItem(itemName, itemQuantity); // Add to RV
                    dialog.dismiss(); // Close dialog
                    Toast.makeText(Inventory.this, "Item added!", Toast.LENGTH_LONG).show();
                }
            }
        });

        cancelAddBtn.setOnClickListener(v -> dialog.dismiss()); // Cancel close dialog
    }

    public void createNewEditItemDialog(int pos, String item, String qty){ // Dialog for editing items
        dialogBuilder = new AlertDialog.Builder(this);
        final View editItemPopupView = getLayoutInflater().inflate(R.layout.popup_edititem, null);
        editItemName = (TextView)  editItemPopupView.findViewById(R.id.edit_item_name);
        editItemQty = (EditText)  editItemPopupView.findViewById(R.id.edit_item_qty);
        submitEditBtn = (Button) editItemPopupView.findViewById(R.id.edit_submit);
        cancelEditBtn = (Button) editItemPopupView.findViewById(R.id.edit_cancel);

        dialogBuilder.setView(editItemPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
        editItemName.setText("Edit " + item + " qty");
        editItemQty.setText(qty);

        submitEditBtn.setOnClickListener(v -> { // Submits changed to DB and RV
            String itemQuantity = editItemQty.getText().toString();
            if (itemQuantity.equals("")) {
                //editError.setText("Please ensure both fields are filled out!");
            } else {
                Boolean itemExists = DB.checkItemExists(item);
                if (itemExists){ // Makes sure that item is in DB
                    // Checks for permission to send SMS and for low qty
                    if (Integer.parseInt(itemQuantity) < 3 && getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendSMS(item);
                    }
                    DB.editItem(item, Integer.parseInt(itemQuantity)); //Edits in DB
                    rvAdapter.editItem(pos, itemQuantity); // Edits in RV
                    dialog.dismiss();
                    Toast.makeText(Inventory.this, "Item quantity changed!", Toast.LENGTH_LONG).show();
                } else {
                    //editError.setText("Item edit failed");
                }
            }
        });

        cancelEditBtn.setOnClickListener(v -> dialog.dismiss());
    }

    private void sendSMS(String item) {
        String phoneNumber = "1234567890";
        if (getApplicationContext().checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
                && getApplicationContext().checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
            TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
            phoneNumber = telephonyManager.getLine1Number();
            String message = "Low Inventory For: " + item;
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } else {
            Toast.makeText(Inventory.this, "No phone number found to send alert to!", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onItemClick(int pos, String item, String qty) {
        createNewEditItemDialog(pos, item, qty);
    }

    @Override
    public void deleteItem(String item) {
        DB.deleteItem(item);
    }
}