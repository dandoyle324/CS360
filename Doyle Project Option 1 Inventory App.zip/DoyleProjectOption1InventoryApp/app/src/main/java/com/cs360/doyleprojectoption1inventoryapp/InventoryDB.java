package com.cs360.doyleprojectoption1inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class InventoryDB extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public InventoryDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ITEM = "item";
        private static final String COL_QTY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_QTY + " integer " + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + InventoryDB.InventoryTable.TABLE);
        onCreate(db);
    }

    public Boolean checkForData() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + DATABASE_NAME, null);

        if (cursor.moveToFirst())
            return true;
        else
            return false;
    }

    public Boolean checkItemExists(String item) {
        SQLiteDatabase db = getWritableDatabase();

        Cursor cursor = db.rawQuery("Select * from inventory where item =?", new String[] {item});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public void addItem(String item, int qty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryDB.InventoryTable.COL_ITEM, item);
        values.put(InventoryDB.InventoryTable.COL_QTY, qty);

        long result = db.insert(InventoryDB.InventoryTable.TABLE, null, values);
        if (result == -1) {
            //failed
        } else {
            //added
        }
    }

    public Boolean editItem(String item, int qty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QTY, qty);
        Cursor cursor = db.rawQuery("select * from " + InventoryTable.TABLE + " where item = ?", new String[]{item});
        if(cursor.getCount()>0){
            long result = db.update(InventoryTable.TABLE, values, "item = ?", new String[]{item});
            if (result == -1){
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }

    }

    public Boolean deleteItem(String item) {
        SQLiteDatabase db = getWritableDatabase();

        Cursor cursor = db.rawQuery("Select * from inventory where item = ?", new String[] { item });
        if (cursor.getCount() > 0) {
            db.delete(InventoryTable.TABLE, InventoryTable.COL_ITEM + " = ?", new String[]{ item });
            return true;
        } else {
            return false;
        }
    }


    public Cursor getItemsInDB() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from inventory", null);
        return cursor;
    }
}
