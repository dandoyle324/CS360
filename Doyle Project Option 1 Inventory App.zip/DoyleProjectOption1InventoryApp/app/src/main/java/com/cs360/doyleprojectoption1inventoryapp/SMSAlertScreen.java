package com.cs360.doyleprojectoption1inventoryapp;

import static java.security.AccessController.getContext;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class SMSAlertScreen extends AppCompatActivity {

    private Button closeSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsalert_screen);

        closeSettings = findViewById(R.id.closeSettings);
        closeSettings.setOnClickListener(view -> {
            Intent intent = new Intent(SMSAlertScreen.this, Inventory.class);
            startActivity(intent);
        });
        Button smsBtn = findViewById(R.id.inventoryAlertBtn);

        smsBtn.setOnClickListener(view -> {
            // Check for permissions
            if (getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(SMSAlertScreen.this, "Send SMS permission already granted!", Toast.LENGTH_SHORT).show();
            } else {
                // request the permission
                requestPermissions(new String[] {Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_PHONE_STATE}, 1);

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 1){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(SMSAlertScreen.this, "Send SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SMSAlertScreen.this, "Send SMS permission denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}