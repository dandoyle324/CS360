package com.cs360.doyleprojectoption1inventoryapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserLogin extends AppCompatActivity {

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    EditText usernameField, passwordField, newuser_username,newuser_password, newuser_password2;
    Button loginButton, newUserButton, newuserpopup_add,newuserpopup_cancel;
    TextView errorMsg, logInError;
    LoginDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        usernameField = (EditText) findViewById(R.id.usernameField);
        passwordField = (EditText) findViewById(R.id.passwordField);
        loginButton = (Button) findViewById(R.id.loginButton);
        newUserButton = (Button) findViewById(R.id.newUserButton);
        logInError = (TextView) findViewById(R.id.logInError);

        DB = new LoginDB(this);

        loginButton.setEnabled(false);

        passwordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (passwordField.getText().toString().trim().equals("")) {
                    loginButton.setEnabled(false);
                } else {
                    loginButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        usernameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (usernameField.getText().toString().trim().equals("")) {
                    loginButton.setEnabled(false);
                } else {
                    loginButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user = usernameField.getText().toString();
                String pass = passwordField.getText().toString();


                Boolean userExists = DB.checkUsername(user);
                if (userExists==false) {
                    logInError.setText("Username not found!");
                }
                else{
                    Boolean userMatched = DB.checkLogin(user, pass);
                    if (userMatched==false){
                        logInError.setText("Password incorrect!");
                    } else {
                        Toast.makeText(UserLogin.this, "Welcome Back", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UserLogin.this, Inventory.class);
                        startActivity(intent);
                    }
                }
            }
        });
    }

    public void newUser(View view) {
        createNewNewUserDialog();
    }

    public void createNewNewUserDialog(){
        dialogBuilder = new AlertDialog.Builder(this);
        final View newUserPopupView = getLayoutInflater().inflate(R.layout.popup_newuser, null);
        newuser_username = (EditText)  newUserPopupView.findViewById(R.id.newuser_username);
        newuser_password = (EditText)  newUserPopupView.findViewById(R.id.newuser_password);
        newuser_password2 = (EditText)  newUserPopupView.findViewById(R.id.newuser_password2);
        newuserpopup_add = (Button) newUserPopupView.findViewById(R.id.newuserpopup_add);
        newuserpopup_cancel = (Button) newUserPopupView.findViewById(R.id.newuserpopup_cancel);
        errorMsg = (TextView) newUserPopupView.findViewById(R.id.error);

        dialogBuilder.setView(newUserPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        newuserpopup_add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String user = newuser_username.getText().toString();
                String pass = newuser_password.getText().toString();
                String repass = newuser_password2.getText().toString();

                Boolean userExists = DB.checkUsername(user);
                if (userExists==true) {
                    errorMsg.setText("Username already in use!");
                }
                else{
                    if (pass.equals(repass)){
                        DB.addUser(user, pass);
                        Toast.makeText(UserLogin.this, "New user added!", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                    else {
                        errorMsg.setText("Your passwords don't match!");
                    }
                }
            }
        });

        newuserpopup_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}