package com.cs360.doyleprojectoption1inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Objects;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.MyViewHolder>{
    private Context context;
    private ArrayList item_name, item_qty;
    private final RVInterface rvInterface;
    private int selectPos = RecyclerView.NO_POSITION;



    public RVAdapter(Context context, ArrayList item_name, ArrayList item_qty,
                     RVInterface rvInterface) {
        this.context = context;
        this.item_name = item_name;
        this.item_qty = item_qty;
        this.rvInterface = rvInterface;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.inventory_row,parent,false);
        return new MyViewHolder(v, rvInterface).linkAdapter(this);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.item_name.setText(String.valueOf(item_name.get(position)));
        holder.item_qty.setText(String.valueOf(item_qty.get(position)));

        holder.itemView.setSelected(selectPos == position);
    }

    @Override
    public int getItemCount() {
        return item_name.size();
    }

    public void addItem(String name, String qty){
        item_name.add(name);
        item_qty.add(qty);
    }

    public void editItem(int pos, String qty) {
        item_qty.remove(pos);
        item_qty.add(pos, qty);
        notifyItemChanged(pos);
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView item_name, item_qty;
        ImageView item_delete;
        private RVAdapter rvAdapter;
        public MyViewHolder(@NonNull View itemView, RVInterface rvInterface) {
            super(itemView);

            item_name = itemView.findViewById(R.id.item_name_text);
            item_qty = itemView.findViewById(R.id.item_qty_text);
            item_delete = itemView.findViewById(R.id.delete_item_btn);

            item_delete.setOnClickListener(view -> {
                if (rvInterface != null) {
                    int pos = getAdapterPosition();
                    String item = item_name.getText().toString();
                    if (pos != RecyclerView.NO_POSITION) {
                        rvInterface.deleteItem(item);
                    }
                }
                rvAdapter.item_name.remove(getAdapterPosition());
                rvAdapter.item_qty.remove(getAdapterPosition());
                rvAdapter.notifyItemRemoved(getAdapterPosition());
            });

            itemView.setOnClickListener(view -> {
                if (rvInterface != null) {
                    int pos = getAdapterPosition();
                    String item = item_name.getText().toString();
                    String qty = item_qty.getText().toString();
                    if (pos != RecyclerView.NO_POSITION) {
                        rvAdapter.notifyItemChanged(pos);
                        int selectedPos = getLayoutPosition();
                        rvAdapter.notifyItemChanged(selectedPos);
                        rvInterface.onItemClick(selectedPos, item, qty);
                    }
                }
            });
        }

        public MyViewHolder linkAdapter(RVAdapter rvAdapter){
            this.rvAdapter = rvAdapter;
            return this;
        }
    }
}
